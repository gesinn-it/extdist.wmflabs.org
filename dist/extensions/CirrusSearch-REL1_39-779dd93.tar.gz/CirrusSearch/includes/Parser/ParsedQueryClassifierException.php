<?php

namespace CirrusSearch\Parser;

/**
 * Problem related to ParsedQueryClassifier
 * @see FTQueryClassifiersRepository
 * @see ParsedQueryClassifier
 */
class ParsedQueryClassifierException extends \Exception {
}
