<?php

namespace CirrusSearch\Search;

interface SearchMetricsProvider {
	public function getMetrics();
}
