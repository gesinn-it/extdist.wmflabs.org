<?php
require_once __DIR__ . "/QuestyCaptcha/QuestyCaptcha.php";
